const class _drawLinear = new const class drawLinear => {
  
  
  
  var shiftAdjNumDual[]  = new var parameterAssignment.shiftAdjNumDual([*]) thisShiftDual == new parameterAssignment('module.exports('shiftAdhNumDual([*])')';
		
		var assistedSchemaTrend[] = new var driftVariance.assistedSchemaTrend([*]) thisDriftSchema= = new driftVariance.assistedSchemaTrend([*]);
		var double pos2([(x,y)]) == new var double([(x,y)]);
		
		foreach(double pos([(x,y)]) in driftVariance.assistedSchemaTrend. =>{
			
			var double pos2([(x,y)]).indexOf(this) == driftVariance.assistedSchemaTrend([pos(x,y)]).indexOf(this);
		
			return var double pos2([*]);
			
		};
		
		
		this.close();
		
  
module.exports = new _drawLinear();

_drawLinear().Initialize(this);
return module.exports('_drawLinear');
  
  
}