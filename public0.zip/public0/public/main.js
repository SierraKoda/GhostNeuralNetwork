const firebaseConfig = {
  apiKey: "AIzaSyAWVwGWhyS4JlPaVQli6wzIK9evptAmhzE",
  authDomain: "ghostnativ.firebaseapp.com",
  databaseURL: "https://ghostnativ.firebaseio.com",
  projectId: "ghostnativ",
  storageBucket: "ghostnativ.appspot.com",
  messagingSenderId: "1046784633298",
  appId: "1:1046784633298:web:ea4aea6e2c3d0e26bf000b",
  measurementId: "G-S10Q31MQVG"
};


var admin = require("firebase-admin");

var serviceAccount = require("path/to/serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://ghostnativ.firebaseio.com"
});


// save me as my-app/index.js
var http = require('http')
var android = require('node-on-android')




var server = http.createServer(function (req, res) {
  res.end(`
    <HTML>
<head>
<h2>::[OmnipuppyXX Coin Encryption Wheel]::</h2>
</head>
<body>

<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/7.9.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/7.9.1/firebase-analytics.js"></script>

<script>
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAWVwGWhyS4JlPaVQli6wzIK9evptAmhzE",
    authDomain: "ghostnativ.firebaseapp.com",
    databaseURL: "https://ghostnativ.firebaseio.com",
    projectId: "ghostnativ",
    storageBucket: "ghostnativ.appspot.com",
    messagingSenderId: "1046784633298",
    appId: "1:1046784633298:web:ea4aea6e2c3d0e26bf000b",
    measurementId: "G-S10Q31MQVG"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
</script>

  <td>
    <tr> <div id='output2'></div></tr>
    <tr> <div id='output'></div></tr>
    <tr> <div id='output3'></div></tr>
  </td>
    <td>
    <tr><p>"RIPEMD160"<p> </tr>
    <tr> <p>"SHA384"</p> </tr>
    <tr> <p>"CDT"</p> </tr>
  </td>
  <td>
    <tr><div id='output4'></div></tr>
  </td>
  <script>
  
  document.getElementById('output').innerHTML = logo143.length ;

    document.getElementById('output2').innerHTML = logoRecache.length ;

    document.getElementById('output3').innerHTML = datetime.length ;

    document.getElementById('output4').innerHTML = consoleText.length ;
    
    </script>

  
</body>
</HTML>
  `)
})

server.listen(0, function () {
  android.loadUrl(`http://localhost:${server.address().port}`)
})

var datetime = new Date(); 
console.log("Welcome to The OmniXX Key Miner" + ":——-::——–:" + datetime + "");
    

    console.log("Please Wait While We Retrieve the Key To Encrypt" + ":——-::——–:" + datetime + "");

	 
    function intervalFunc() { console.log('');
      var x=1; while (x!=0){
	 
    var sourceFile = "319572770adf3b1ea3a801732fe90f17e346c6565b2426c2bdf398d9842bb26f266cd5df2515c3c43c10f19570c0cf216213d0109452e7677c610a368c8cdb9e:3aO:3512:335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE";
  var logo =   
sourceFile;
    
      var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo, 'utf-8');
gen_hash= data.digest('hex');
var logo2 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo2 + ""); 
     
    
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo2, 'utf-8');
gen_hash= data.digest('hex');
var logo3 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo3 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo3, 'utf-8');
gen_hash= data.digest('hex');
var logo4 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo4 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo4, 'utf-8');
gen_hash= data.digest('hex');
var logo5 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo5 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo5, 'utf-8');
gen_hash= data.digest('hex');
var logo6 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo6 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo6, 'utf-8');
gen_hash= data.digest('hex');
var logo7 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo7 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo7, 'utf-8');
gen_hash= data.digest('hex');
var logo8 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo8 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo8, 'utf-8');
gen_hash= data.digest('hex');
var logo9 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo9 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo9, 'utf-8');
gen_hash= data.digest('hex');
var logo10 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo10 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo10, 'utf-8');
gen_hash= data.digest('hex');
var logo11 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo11 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo11, 'utf-8');
gen_hash= data.digest('hex');
var logo12 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo12 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo12, 'utf-8');
gen_hash= data.digest('hex');
var logo13 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo13 + ""); 
    var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo13, 'utf-8');
gen_hash= data.digest('hex');
var logo14 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo14 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo14, 'utf-8');
gen_hash= data.digest('hex');
var logo15 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo15 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo15, 'utf-8');
gen_hash= data.digest('hex');
var logo16 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo16 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo16, 'utf-8');
gen_hash= data.digest('hex');
var logo17 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo17 + ""); 
     
             
    var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo17, 'utf-8');
gen_hash= data.digest('hex');
var logo18 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo18 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo18, 'utf-8');
gen_hash= data.digest('hex');
var logo19 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo19 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo19, 'utf-8');
gen_hash= data.digest('hex');
var logo20 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo20 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo20, 'utf-8');
gen_hash= data.digest('hex');
var logo21 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo21 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo21, 'utf-8');
gen_hash= data.digest('hex');
var logo22 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo22 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo22, 'utf-8');
gen_hash= data.digest('hex');
var logo23 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo23 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo23, 'utf-8');
gen_hash= data.digest('hex');
var logo24 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo24 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo24, 'utf-8');
gen_hash= data.digest('hex');
var logo25 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo25 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo25, 'utf-8');
gen_hash= data.digest('hex');
var logo26 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo26 + ""); 
     
           
    var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo26, 'utf-8');
gen_hash= data.digest('hex');
var logo27 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo27 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo27, 'utf-8');
gen_hash= data.digest('hex');
var logo28 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo28 + ""); 
     
                 
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo28, 'utf-8');
gen_hash= data.digest('hex');
var logo29 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo29 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo29, 'utf-8');
gen_hash= data.digest('hex');
var logo30 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo30 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo30, 'utf-8');
gen_hash= data.digest('hex');
var logo31 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo31 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo31, 'utf-8');
gen_hash= data.digest('hex');
var logo32 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo32 + ""); 
     
           var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo32, 'utf-8');
gen_hash= data.digest('hex');
var logo33 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo33 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo33, 'utf-8');
gen_hash= data.digest('hex');
var logo34 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo34 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo34, 'utf-8');
gen_hash= data.digest('hex');
var logo35 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo35 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo35, 'utf-8');
gen_hash= data.digest('hex');
var logo36 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo36 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo36, 'utf-8');
gen_hash= data.digest('hex');
var logo37 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo37 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo37, 'utf-8');
gen_hash= data.digest('hex');
var logo38 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo38 + ""); 
     
        
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo38, 'utf-8');
gen_hash= data.digest('hex');
var logo39 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo39 + ""); 
     
          
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo39, 'utf-8');
gen_hash= data.digest('hex');
var logo40 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo40 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo40, 'utf-8');
gen_hash= data.digest('hex');
var logo41 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo41 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo41 , 'utf-8');
gen_hash= data.digest('hex');
var logo42 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo42 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo42 , 'utf-8');
gen_hash= data.digest('hex');
var logo43 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo43 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo43, 'utf-8');
gen_hash= data.digest('hex');
var logo44 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo44 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo44, 'utf-8');
gen_hash= data.digest('hex');
var logo45 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo45 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo45, 'utf-8');
gen_hash= data.digest('hex');
var logo46 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo46 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo46, 'utf-8');
gen_hash= data.digest('hex');
var logo47 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo47 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo47, 'utf-8');
gen_hash= data.digest('hex');
var logo48 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo48 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo48, 'utf-8');
gen_hash= data.digest('hex');
var logo49 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo49 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo49, 'utf-8');
gen_hash= data.digest('hex');
var logo50 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo50 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo50, 'utf-8');
gen_hash= data.digest('hex');
var logo51 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo51 + ""); 
    var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo51, 'utf-8');
gen_hash= data.digest('hex');
var logo52 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo52 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo52, 'utf-8');
gen_hash= data.digest('hex');
var logo53 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo53 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo53, 'utf-8');
gen_hash= data.digest('hex');
var logo54 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo54 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo54, 'utf-8');
gen_hash= data.digest('hex');
var logo55 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo55 + ""); 
     
            
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo55, 'utf-8');
gen_hash= data.digest('hex');
var logo56 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo56 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo56, 'utf-8');
gen_hash= data.digest('hex');
var logo57 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo57 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo57, 'utf-8');
gen_hash= data.digest('hex');
var logo58 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo58 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo58, 'utf-8');
gen_hash= data.digest('hex');
var logo59 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo59 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo59, 'utf-8');
gen_hash= data.digest('hex');
var logo60 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo60 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo60, 'utf-8');
gen_hash= data.digest('hex');
var logo61 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo61 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo61, 'utf-8');
gen_hash= data.digest('hex');
var logo62 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo62 + ""); 
     
       
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo62, 'utf-8');
gen_hash= data.digest('hex');
var logo63 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo63 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo63, 'utf-8');
gen_hash= data.digest('hex');
var logo64 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo64 + ""); 
     
        var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo64, 'utf-8');
gen_hash= data.digest('hex');
var logo65 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo65 + ""); 
     
            
                         
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo65, 'utf-8');
gen_hash= data.digest('hex');
var logo66 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo66 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo66, 'utf-8');
gen_hash= data.digest('hex');
var logo67 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo67 + ""); 
     
       
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo67, 'utf-8');
gen_hash= data.digest('hex');
var logo68 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo68 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo68, 'utf-8');
gen_hash= data.digest('hex');
var logo69 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo69 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo69, 'utf-8');
gen_hash= data.digest('hex');
var logo70 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo70 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo70, 'utf-8');
gen_hash= data.digest('hex');
var logo71 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo71 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo71, 'utf-8');
gen_hash= data.digest('hex');
var logo72 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo72 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo72, 'utf-8');
gen_hash= data.digest('hex');
var logo73 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo73 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo73, 'utf-8');
gen_hash= data.digest('hex');
var logo74 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo74 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo74, 'utf-8');
gen_hash= data.digest('hex');
var logo75 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo75 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo75, 'utf-8');
gen_hash= data.digest('hex');
var logo76 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo76 + ""); 
     
               
    var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo76, 'utf-8');
gen_hash= data.digest('hex');
var logo76 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo76 + ""); 
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo76, 'utf-8');
gen_hash= data.digest('hex');
var logo77 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo77 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo77, 'utf-8');
gen_hash= data.digest('hex');
var logo78 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo78 + ""); 
     var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo78, 'utf-8');
gen_hash= data.digest('hex');
var logo79 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo79 + ""); 
     
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo79, 'utf-8');
gen_hash= data.digest('hex');
var logo80 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo80 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo80, 'utf-8');
gen_hash= data.digest('hex');
var logo81 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo81 + ""); 
     
       var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo81, 'utf-8');
gen_hash= data.digest('hex');
var logo82 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo82 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo82, 'utf-8');
gen_hash= data.digest('hex');
var logo83 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo83 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo83, 'utf-8');
gen_hash= data.digest('hex');
var logo84 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo84 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo84, 'utf-8');
gen_hash= data.digest('hex');
var logo85 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo85 + ""); 
    var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo85, 'utf-8');
gen_hash= data.digest('hex');
var logo86 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo86 + ""); 
     
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo86, 'utf-8');
gen_hash= data.digest('hex');
var logo87 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo87 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo87, 'utf-8');
gen_hash= data.digest('hex');
var logo88 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo88 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo88, 'utf-8');
gen_hash= data.digest('hex');
var logo89 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo89 + ""); 
     
         
     var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo89, 'utf-8');
gen_hash= data.digest('hex');
var logo90 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo90 + ""); 
    var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo90, 'utf-8');
gen_hash= data.digest('hex');
var logo91 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo91 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo91, 'utf-8');
gen_hash= data.digest('hex');
var logo92 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo92 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo92, 'utf-8');
gen_hash= data.digest('hex');
var logo93 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo93 + ""); 
      
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo93, 'utf-8');
gen_hash= data.digest('hex');
var logo94 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo94 + ""); 
         
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo94, 'utf-8');
gen_hash= data.digest('hex');
var logo95 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo95 + ""); 
          
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo95, 'utf-8');
gen_hash= data.digest('hex');
var logo96 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo96 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo96, 'utf-8');
gen_hash= data.digest('hex');
var logo97 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo97 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo97, 'utf-8');
gen_hash= data.digest('hex');
var logo98 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo98 + ""); 
  var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo98, 'utf-8');
gen_hash= data.digest('hex');
var logo99 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo99 + ""); 
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo99, 'utf-8');
gen_hash= data.digest('hex');
var logo100 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo100 + ""); 
       
 var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo100, 'utf-8');
gen_hash= data.digest('hex');
var logo101 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo101 + ""); 
     
var crypto = require('crypto');
var hash = crypto.createHash('ripemd160');
data = hash.update(logo101, 'utf-8');
gen_hash= data.digest('hex');
var logo102 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo102 + "");
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo102, 'utf-8');
gen_hash= data.digest('hex');
var logo103 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo103 + "");

    
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo103, 'utf-8');
gen_hash= data.digest('hex');
var logo104 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo104 + ""); 
 
 var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo104, 'utf-8');
gen_hash= data.digest('hex');
var logo105 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo105 + ""); 
      
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo105, 'utf-8');
gen_hash= data.digest('hex');
var logo106 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo106 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo106, 'utf-8');
gen_hash= data.digest('hex');
var logo107 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo107 + ""); 

    
 var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo107, 'utf-8');
gen_hash= data.digest('hex');
var logo108 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo108 + ""); 
 
 var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo108, 'utf-8');
gen_hash= data.digest('hex');
var logo109 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo109 + ""); 
      
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo109, 'utf-8');
gen_hash= data.digest('hex');
var logo110 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo110 + ""); 
    
   
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo110, 'utf-8');
gen_hash= data.digest('hex');
var logo111 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo111 + ""); 

 var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo111, 'utf-8');
gen_hash= data.digest('hex');
var logo112 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo112 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo112, 'utf-8');
gen_hash= data.digest('hex');
var logo113 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo113 + ""); 
 var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo113, 'utf-8');
gen_hash= data.digest('hex');
var logo114 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo114 + ""); 
     
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo114, 'utf-8');
gen_hash= data.digest('hex');
var logo115 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo115 + ""); 
        
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo115, 'utf-8');
gen_hash= data.digest('hex');
var logo116 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo116 + ""); 
      
 var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo116, 'utf-8');
gen_hash= data.digest('hex');
var logo117 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo117 + ""); 
 var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo117, 'utf-8');
gen_hash= data.digest('hex');
var logo118 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo118 + ""); 
 var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo118, 'utf-8');
gen_hash= data.digest('hex');
var logo119 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo119 + ""); 
             
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo119, 'utf-8');
gen_hash= data.digest('hex');
var logo120 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo120 + ""); 
        
 var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo120, 'utf-8');
gen_hash= data.digest('hex');
var logo121 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo121 + ""); 
          
 var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo121, 'utf-8');
gen_hash= data.digest('hex');
var logo122 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo122 + ""); 
          
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo122, 'utf-8');
gen_hash= data.digest('hex');
var logo123 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo123 + ""); 
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo123, 'utf-8');
gen_hash= data.digest('hex');
var logo124 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo124 + ""); 
       
var crypto = require('crypto');
var hash = crypto.createHash('ripemd160');
data = hash.update(logo124, 'utf-8');
gen_hash= data.digest('hex');
var logo125 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo125 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo125, 'utf-8');
gen_hash= data.digest('hex');
var logo126 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo126 + ""); 
    
   var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo126, 'utf-8');
gen_hash= data.digest('hex');
var logo127 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo127 + ""); 
    
    
  var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo127, 'utf-8');
gen_hash= data.digest('hex');
var logo128 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo128 + ""); 
     
    var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo128, 'utf-8');
gen_hash= data.digest('hex');
var logo129 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo129 + ""); 
    
  var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo129, 'utf-8');
gen_hash= data.digest('hex');
var logo130 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo130 + ""); 
     
  var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo130, 'utf-8');
gen_hash= data.digest('hex');
var logo131 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo131 + ""); 
     
var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo131, 'utf-8');
gen_hash= data.digest('hex');
var logo132 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo132 + ""); 

var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo132, 'utf-8');
gen_hash= data.digest('hex');
var logo133 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo133 + ""); 
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo133, 'utf-8');
gen_hash= data.digest('hex');
var logo134 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo134 + ""); 
       
var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo134, 'utf-8');
gen_hash= data.digest('hex');
var logo135 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo135 + ""); 
    
    var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo135, 'utf-8');
gen_hash= data.digest('hex');
var logo136 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo136 + ""); 
       
 var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo136, 'utf-8');
gen_hash= data.digest('hex');
var logo137 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo137 + ""); 
     
var crypto = require('crypto');
var hash = crypto.createHash('ripemd160');
data = hash.update(logo137, 'utf-8');
gen_hash= data.digest('hex');
var logo138 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo138 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha1');
data = hash.update(logo138, 'utf-8');
gen_hash= data.digest('hex');
var logo139 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo139 + ""); 
 
 var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo139, 'utf-8');
gen_hash= data.digest('hex');
var logo140 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo140 + ""); 
      
var crypto = require('crypto');
var hash = crypto.createHash('sha512');
data = hash.update(logo140, 'utf-8');
gen_hash= data.digest('hex');
var logo141 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo141 + ""); 
    
var crypto = require('crypto');
var hash = crypto.createHash('sha256');
data = hash.update(logo141, 'utf-8');
gen_hash= data.digest('hex');
var logo142 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo142 + ""); 

    
 var crypto = require('crypto');
var hash = crypto.createHash('sha384');
data = hash.update(logo142, 'utf-8');
gen_hash= data.digest('hex');
var logo143 = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logo143 + ""); 
 
 
    
var crypto = require('crypto');
var hash = crypto.createHash('ripemd160');
data = hash.update(logo143, 'utf-8');
gen_hash= data.digest('hex');
var logoRipe = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE"  ;
console.log("hash: " + logoRipe + ""); 
  
      	
    	
    
    var crypto = require('crypto');
var hash = crypto.createHash('ripemd160');
data = hash.update(logoRipe, 'utf-8');
gen_hash= data.digest('hex');
var logoRecache = gen_hash + "" + datetime + "" + "335253122353132313321BASE23522135311523133235BASE353253153323532313325BASE135323531321531523531BASE323153512352531353215BASE532313525355332333235BASE";


console.log("hash: " + logoRecache + ""); 

//var logoStr = Buffer.from(logoRecache);

// public callStr = logoStr.toString();


window.onload = function(){
	front.send('get-data', app.getPath('userData'));
	

    document.getElementById('output').innerHTML = logo143;

    document.getElementById('output2').innerHTML = logoRecache;

    document.getElementById('output3').innerHTML = datetime;

    document.getElementById('output4').innerHTML = consoleText;
	
         }
    
      }  
    
 // console.log(callStr.toString());


String stringItem == console.toString(*);
        String consoleText == String stringItem.length ;
        
  x++;
  
  
  }setInterval(intervalFunc, 1000); 