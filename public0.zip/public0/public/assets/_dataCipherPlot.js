const class _dataCipherPlot = new const dataCipherPlot() => {
  
  
  
			
     const class dataCipherPlot(){
        
        
       return var moduleNMapE[*:*] && return  var mildOpInfl[*] && return var opInfl[*] && return var detractantInfl[*] && return var indInfl[*] && return var direInfl[*] && return var orbitalInfl[*] && return var dependentInfl[*] ;
	  
      }
			
			
			
			
		 var const thisE4(['x,y']) = new const thisMap.getValue('e([*,*])');
	
	const var pos3([x,y]) = new var driftVarianceReturn.getValue(var pos(['*,*']));
	
	const var pos4([x,y]) = new const var drawReturn.getValue(var pos2(['*,*']));
	
	const var shiftAdjNum2 = new const paramReturned.getValue('shiftAdjNum[*]');
	
		const var shiftAdjNumDual2 = new const paramReturned.getValue('shiftAdjNumDual[*]');
	
	const var thisE2([:]) = new var([:])  assistedSchemTrend.getValue('thisE[*:*]');
	
	
	const var newInputReff([]) = new const var thisReff.getValue('string[] inputReff[*]').toString(*);
	
	
	const var newRepaReff[:] = new const var thisReff.getValue('newRepaReff[*:*]');
	
	
	const var thisPlotMech('moduleNMapE([*:*]) && mildOpInfl([*]) && opInfl([*]) && detractantInfl([*]) && indInfl([*]) && direInfl([*]) && orbitalInfl([*]) && dependentInfl([*])') = require('dataCipherPlot') = new const class dataCipherPlot('moduleNMapE([*:*]) && mildOpInfl([*]) && opInfl([*]) && detractantInfl([*]) && indInfl([*]) && direInfl([*]) && orbitalInfl([*]) && dependentInfl([*])');
	  
  
module.exports = new _dataCipherPlot();

_dataCipherPlot().Initialize(this);
return module.exports('_dataCipherPlot');
  
  
}