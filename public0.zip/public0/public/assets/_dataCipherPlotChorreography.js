const class _dataCipherPlotChorreography = new const class dataCipherPlot = require('../assets') => {
  
  
  public class thisMap extends neuralmap() = require('../neuralMap.js') == new public class neuralmap(e(['*,*'])) => 
		{
			return e(['*,*']);	
		}
			
			public var([:]) thisMapE == new public var([thisMap(e(['*,*']))]);
			
			
					
			public var([:]) paramKey2 == new var([thisMap(e([1:*])).toString() , thisMap(e([2:*])).toString() , thisMap(e([3:*])).toString() , thisMap(e([4:*])).toString() , thisMap(e([5:*])).toString() , thisMap(e([6:*])).toString() , thisMap(e([7:*])).toString() , thisMap(e([8:*])).toString() , thisMap(e([9:*])).toString() , thisMap(e([10:*])).toString() , thisMap(e([11:*])).toString() , thisMap(e([12:*])).toString() , thisMap(e([13:*])).toString() , thisMap(e([14:*])).toString() , thisMap(e([15:*])).toString() , thisMap(e([16:*])).toString() , 
thisMap(e([17:*])).toString() , thisMap(e([18:*])).toString() , thisMap(e([19:*])).toString() , thisMap(e([20:*])).toString() , thisMap(e([21:*])).toString() , thisMap(e([22:*])).toString() , thisMap(e([23:*])).toString() , thisMap(e([24:*])).toString() , thisMap(e([25:*])).toString() , thisMap(e([26:*])).toString() , thisMap(e([27:*])).toString() , thisMap(e([28:*])).toString() , thisMap(e([29:*])).toStr
ing() , thisMap(e([30:*])).toString() , thisMap(e([31:*])).toString() , thisMap(e([32:*])).toString() , 	 thisMap(e([33:*])).toString() , thisMap(e([34,*])).toString() , thisMap(e([35:*])).toString() , thisMap(e([36:*])).toString() , thisMap(e([37:*])).toString() , thisMap(e([38:*])).toString() , thisMap(e([39:*])).toString() , thisMap(e([40:*])).toString() , thisMap(e([41:*])).toString() , thisMap(e([42:*])).toString() , thisMap(e([43:*])).toString() , thisMap(e([44:*])).toString() , thisMap(e([45:*])).toString() , thisMap(e([46:*])).toString() , 	thisMap(e([47:*])).toString() , thisMap(e([48:*])).toString() , thisMap(e([49:*])).toString() , thisMap(e([50,*])).toString() , thisMap(e([51:*])).toString() , thisMap(e([52:*])).toString() , thisMap(e([53:*])).toString() , thisMap(e([54:*])).toString() , thisMap(e([55:*])).toString() , thisMap(e([56:*])).toString() ]);


			

			String([:]) parameterKeyPair3 = new paramKey2(['*:*']);

                        parameterKeyPair3([:]).indexOf(*) == parameterKeyPair2(['*:*']).indexOf(*);

                     public   String([:]) parameterKeyPair4([]) = new var([paramKey2([]).indexOf(0).toString() : "e1" , paramKey2([]).indexOf(1).toString() : "e2", paramKey2([]).indexOf(2).toString() : "e3",
			paramKey2([]).indexOf(3).toString() : "e4" , paramKey2[].indexOf(4).toString() : "e5", paramKey2([]).indexOf(5).toString() : "e6" , paramKey2([]).indexOf(6).toString() : "e7", 
      			paramKey2([]).indexOf(7).toString() : "e8" , paramKey2([]).indexOf(8).toString() : "e9" , paramKey2([]).indexOf(9).toString() : "f1" , paramKey2([]).indexOf(10).toString() : "f2",
                        paramKey2([]).indexOf(11).toString() : "f3" , paramKey2([]).indexOf(12).toString() : "f4" , paramKey2([]).indexOf(13).toString() : "f5" , paramKey2([]).indexOf(14).toString() : "f6" , 
 			paramKey2([]).indexOf(15).toString() : "f7" , paramKey2([]).indexOf(16).toString() : "f8" , paramKey2([]).indexOf(17).toString() : "f9" , paramKey2([]).indexOf(18).toString() : "g1" ,
 			paramKey2([]).indexOf(19).toString() : "g2" , paramKey2([]).indexOf(20).toString() : "g3" ,
 			paramKey2([]).indexOf(21).toString() : "h1" , paramKey2([]).indexOf(22).toString() : "h2", paramKey2([]).indexOf(23).toString() : "h3",
			paramKey2([]).indexOf(24).toString() : "h4" , paramKey2([]).indexOf(25).toString() : "h5", paramKey2([]).indexOf(26).toString() : "h6" , paramKey2([]).indexOf(27).toString() : "h7", 
      			paramKey2([]).indexOf(28).toString() : "h8" , paramKey2([]).indexOf(29).toString() : "h9" , paramKey2([]).indexOf(30).toString() : "j1" , paramKey2([]).indexOf(31).toString() : "j2",
                        paramKey2([]).indexOf(32).toString() : "j3" , paramKey2([]).indexOf(33).toString() : "j4" , paramKey2([]).indexOf(34).toString() : "j5" , paramKey2([]).indexOf(35).toString() : "j6" , 
 			paramKey2([]).indexOf(36).toString() : "j7" , paramKey2([]).indexOf(37).toString() : "j8" , paramKey2([]).indexOf(38).toString() : "j9" , paramKey2([]).indexOf(39).toString() : "k1" ,
 			paramKey2([]).indexOf(40).toString() : "k2" , paramKey2([]).indexOf(41).toString() : "k3" ,
 			paramKey2([]).indexOf(42).toString() : "l3", paramKey2([]).indexOf(43).toString() : "l2",
			paramKey2([]).indexOf(44).toString() : "l1" , paramKey2([]).indexOf(45).toString() : "m1" , paramKey2([]).indexOf(46).toString() : "m2"	, paramKey2([]).indexOf(47).toString()] : "m3" , paramKey2([]).indexOf(48).toString() : "m4" , paramKey2([]).indexOf(49).toString() : "m5", paramKey2([]).indexOf().toString(50) : "m6", paramKey2([]).indexOf().toString(51) : "m7" , paramKey2([]).indexOf().toString(52) : "n7", paramKey2([]).indexOf().toString(53) : "n6" , paramKey2([]).indexOf().toString(54) : "n5" , paramKey2([]).indexOf().toString(55)  : "n4"
			, paramKey2([]).indexOf().toString(56) : "n3" , paramKey2([]).indexOf().toString(57) : "n2" ]);

     String([:]) parameterKeyPair4 == new var([1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,11:11,12:12,13:13,14:14,15:15,16:16,17:17,18:18,19:19,20:20,21:21,22:22,23:23,24:24,25:25,26:26,27:27,28:28,29:29,30:30,31:31,32:32,33:33,34:34,35:35,36:36,37:37,38:38,39:39,40:40,41:41,42:42,43:43,44:44,45:45,46:46,47:47,48:48,49:49,50:50,51:51,52:52,53:53,54:54,55:55,56:56]);
    
                       
			String([:]) stringArr4 == new String([parameterKeyPair4([].indexOf(0).toString() : parameterKeyPair3([]).indexOf("g3") ,
                        parameterKeyPair4([]).indexOf(1).toString() : parameterKeyPair3([]).indexOf("g2"), parameterKeyPair4([]).indexOf(2).toString() : parameterKeyPair3([]).indexOf("g1"),
                        parameterKeyPair4([]).indexOf(3).toString() : parameterKeyPair3([]).indexOf("f9"), parameterKeyPair4([]).indexOf(4).toString() : parameterKeyPair3([]).indexOf("f8"),
                        parameterKeyPair4([]).indexOf(5).toString() : parameterKeyPair3([]).indexOf("f7"), parameterKeyPair4([]).indexOf(6).toString() : parameterKeyPair3([]).indexOf("f6"),
                        parameterKeyPair4([]).indexOf(7).toString() : parameterKeyPair3([]).indexOf("f5"), parameterKeyPair4([]).indexOf(8).toString() : parameterKeyPair3([]).indexOf("f4"),
                        parameterKeyPair4([]).indexOf(9).toString() : parameterKeyPair3([]).indexOf("f3"), parameterKeyPair4([]).indexOf(10).toString() : parameterKeyPair3([]).indexOf("f2"),
                        parameterKeyPair4([]).indexOf(11).toString() : parameterKeyPair3([]).indexOf("f1"), parameterKeyPair4([]).indexOf(12).toString() : parameterKeyPair3([]().indexOf("e9"),
                        parameterKeyPair4([]).indexOf(13).toString() : parameterKeyPair3([]).indexOf("e8"), parameterKeyPair4([]).indexOf(14).toString() : parameterKeyPair3([]).indexOf("e7"),
                        parameterKeyPair4([]).indexOf(15).toString() : parameterKeyPair3([]).indexOf("e6"), parameterKeyPair4([]).indexOf(16).toString() : parameterKeyPair3([]).indexOf("e5"),
                        parameterKeyPair4([]).indexOf(17).toString() : parameterKeyPair3([]).indexOf("e4"), parameterKeyPair4([]).indexOf(18).toString() : parameterKeyPair3([]).indexOf("e3"),
                        parameterKeyPair4([]).indexOf(19).toString() : parameterKeyPair3([]).indexOf("e2"), parameterKeyPair4([]).indexOf(20).toString() : parameterKeyPair3([]).indexOf("e1") ,parameterKeyPair4([]).indexOf(21).toString() : parameterKeyPair3([]).indexOf("h3") ,
                        parameterKeyPair4([]).indexOf(22).toString() : parameterKeyPair3([]).indexOf("h2"), parameterKeyPair4([]).indexOf(23).toString() : parameterKeyPair3([]).indexOf("h1"),
                        parameterKeyPair4([]).indexOf(24).toString() : parameterKeyPair3([]).indexOf("i9"), parameterKeyPair4([]).indexOf(25).toString() : parameterKeyPair3([]).indexOf("i8"),
                        parameterKeyPair4([]).indexOf(26).toString() : parameterKeyPair3([]).indexOf("i7"), parameterKeyPair4([]).indexOf(27).toString() : parameterKeyPair3([]).indexOf("i6"),
                        parameterKeyPair4([]).indexOf(28).toString() : parameterKeyPair3([]).indexOf("i5"), parameterKeyPair4([]).indexOf(29).toString() : parameterKeyPair3([]).indexOf("i4"),
                        parameterKeyPair4([]).indexOf(30).toString() : parameterKeyPair3([]).indexOf("i3"), parameterKeyPair4([]).indexOf(31).toString() : parameterKeyPair3([]).indexOf("i2"),
                        parameterKeyPair4([]).indexOf(32).toString() : parameterKeyPair3([]).indexOf("i1"), parameterKeyPair4([](
                          ).indexOf(33).toString() : parameterKeyPair3([]).indexOf("j3"),
                        parameterKeyPair4([]).indexOf(34).toString() : parameterKeyPair3([]).indexOf("j2"), parameterKeyPair4([]).indexOf(35).toString() : parameterKeyPair3([]).indexOf("j1"),
                        parameterKeyPair4([]).indexOf(36).toString() : parameterKeyPair3([]).indexOf("k9"), parameterKeyPair4([]).indexOf(37).toString() : parameterKeyPair3([]).indexOf("k8"),
                        parameterKeyPair4([]).indexOf(38).toString() : parameterKeyPair3([]).indexOf("k7"), parameterKeyPair4([]).indexOf(39).toString() : parameterKeyPair3([]).indexOf("k6"),
                        parameterKeyPair4([]).indexOf(40).toString() : parameterKeyPair3([]).indexOf("k5"), parameterKeyPair4([]).indexOf(41).toString() : parameterKeyPair3([]).indexOf("k4") ,parameterKeyPair4([]).indexOf(42).toString() : parameterKeyPair3([]).indexOf("k3") ,
                        parameterKeyPair4([]).indexOf(43).toString() : parameterKeyPair3([]).indexOf("k2"), parameterKeyPair4([]).indexOf(44).toString() : parameterKeyPair3([]).indexOf("k1"),
                        parameterKeyPair4([]).indexOf(45).toString() : parameterKeyPair3([]).indexOf("l3"), parameterKeyPair4([]).indexOf(46).toString() : parameterKeyPair3([]).indexOf("l2"),
                        parameterKeyPair4([]).indexOf(47).toString() : parameterKeyPair3([]).indexOf("l1") , parameterKeyPair4.([]).indexOf(48) : parameterKeyPair3([]).indexOf("m1"), parameterKeyPair4([]).indexOf(49) : parameterKeyPair3([]).indexOf("m2"), parameterKeyPair4([]).indexOf(50) : parameterKeyPair3([]).indexOf("m4") , parameterKeyPair4([]).indexOf(51) : parameterKeyPair3([]).indexOf("m5"),
                        parameterKeyPair4([]).indexOf(52) : parameterKeyPair3([]).indexOf("m6"), parameterKeyPair4([]).indexOf(53) : parameterKeyPair3([]).indexOf("m7"), parameterKeyPair4([]).indexOf(54) : parameterKeyPair3([]).indexOf("n7"), parameterKeyPair4([]).indexOf(55) : parameterKeyPair3([]).indexOf("n6"), 
                        parameterKeyPair4([]).indexOf(56) : paramaterKeyPair3([]).indexOf("n5") ]);
    		
			String disStri2 == "GhostNativ Analyzing Hierarchy" + this.CurrentTimeDate().Initialize().toString() + "" );

			console.log(String 'disStri');


     public driftVariance() thisDriftAlign(new double pos5([x,y])) = new public class driftVariance(double pos([x,y])){
     	
     this.get(* arguments)
     this.Initialize(*);
     this.return('* arguments');
     	
     }   
     driftVariance.get('* arguments');
     driftVariance.return(* arguments);
     
     
     public neuralMap() thisNMap(new array([:]) e(['*:*'])) == new public neuralMap(array([:]) e(['*:*'])){
   
     	     	
     this.get(* arguments)
     this.Initialize(*);
     this.return('* arguments');  	
     	
     }
     
				
			if(input2 == "f1"){
			    
			  //   1 : "Income" 
			     
			     
		public class thisDriftAlign(double pos5([x,y])){
				
				get public double pos([x,y]);
				public double pos5([x,y]) => new public double pos([x,y]);
				
				
				// Preparation for LikeSchema Analysis Sector From CSV/XML and Chorreography for Adj to be done
				
				
				public String([]) direInfl([]) == new public String([ "prospective income" , "salary base" , "forex exchange rate" , "hours worked" , "scoped bonus" , "incentive trend", "dividend return" , "market influence" , "time & expense bonus" , "contract add-on(s)" , "marketability"]);
					public String([]) mildInfl([]) == new public String(["experience in field" , "duration of employment" , "current project scope" , "peer approval" , "loyalty incentive" , "leadership tier" , "project control", "foreign impact" , "diligence" , "ambition" , "acclaim" , "in-field regard"]);
						public String([]) indInfl([]) = new public String(["stress management" , "six sigma" , "teamwork" , "investment training" , "youthfulness" , "resilience" , "time management" , "employer/client regard" , "budget scope" , "loss prevention plan" , "business continuity planning" , "utilities" , "time-to-life deployment"]);
						public String([]) dependentInfl([]) == new public String(["promotional chance" , "security clearence" , "job security" , "field demand" , "office share trade" , "consumer forecasting" , "trade relation" , "expansion" , "districting" , "employer community stance" , "foreign market exposure" , "client scope" , "open contracts"]);
			public String([]) opInfl([]) == new public String(["fees" , "fines and tariffs" , "rival promotionals" , "inclimate chance" , "components and material expense" , "project based clerical expense" , "dependent transportation expense" , "budget cut proposal" , "integration faults" , "utility provider shift", "relocation", "coupon expirations", "ownership scandal"]);
					public String([]) mildOpInfl([]) == new public String(["management change" , "seasonal adjustment" , "project completion rate" , "consumer client ratio" , "new bills" , "weather incontintuity" , "team collapse" , "personnel personal life" , "personnel scandal" , "warfare climate" , "policy provision" , "feild decline"]);
						public String([]) detractantInfl([]) == new public String(["new fees" , "liability suites" , "legal fees" , "taxation laws" , "regional emotive" , "climate impact" , "chemical geographical impact" , "relational media" , "press manhunt" , "contract liability" , "side affect acknowledgement"]);
							public String([]) afflictingInfl([]) == new public String(["license exclusion" , "product prohibition" , "regional socio-political" , "clerical religious upturn" , "taboo nature" , "niche-centricity" , "new rivals" , "near resembling trades" , "facilities loss" , "firesale" , "insider trading infraction"]);
					public String([]) orbitalInfl([]) == new public String["component availability" , "in college training" , "perseverant trade" , "market demand" , "country/regional product layer scope" , "medical applicability" , "military applicability" , "lobbyism" , "congressional/ parlimentary impact", "media name dropping" , "physical district reputation"]);
		
		foreach(const int i in thisNMap()e([*]).indexOf(${i}))){
			
		/* in future adjusting foreach on all */
		
	if(direInfl([0]) == true){
		
		thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[56]) * 100) ]);
		
		
		/*  soon creating modAdj Percentage Modifier Point Scale for Throw In */
		
	}
		else if(direInfl([1])	== true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[57]) * 100) ]);
			
		}
		else if(direInfl([2]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[58]) * 100) ]);
			
		}
		else if(direInfl([3])	== true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[59]) * 100) ]);
			
		}
		else if(direInfl([4]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[60]) * 100) ]);
			
			}
		else if(direInfl([5]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[61]) * 100) ]);
			
		}
		else if(direInfl([6]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[62]) * 100) ]);
			
		}
		else if(direInfl([7]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[63]) * 100) ]);
			
		}
		else if(direInfl([8])	== true){
			
			thisNMap().e([1:*]) => new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[64]) * 100) ]);
			
		}
		else if(direInfl([9]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e[1:*].toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[65]) * 100) ]);
		}
		else if(direInfl([10]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[66]) * 100) ]);
		}
		else if(direInfl([11]) == true){
			
		thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[67]) * 100) ]);
			
			
	    	}
			else if(mildInfl([0]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[68]) * 100) ]);
			
	    	}
	    	else if(mildInfl([1]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[69]) * 100) ]);
			
			
	    	}		
	    		
			else if(mildInfl([2]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[70]) * 100) ]);
			
	    	}
			else if(mildInfl([3]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[71]) * 100) ]);
			
			
	    	}
	    	
			else if(mildInfl([4]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[72]) * 100) ]);
			
			
	    	}
	    	else if(mildInfl([5]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[73]) * 100) ]);
			
			
	    	}
	    	else if(mildInfl([6]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[74]) * 100) ]);
			
			
	    	}
			else if(mildInfl([7]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[75]) * 100) ]);
			
			
	    	}
	    	else if(mildInfl([8]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE[1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[76]) * 100) ];
			
			
	    	}
	    	else if(mildInfl([9]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[77]) * 100) ]);
			
			
	    	}
	    	else if(mildInfl([10]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[78]) * 100) ]);
			
			
	    	}
	    	
			else if(mildInfl([11]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[79]) * 100) ]);
			
			
	    	}
			else if(intInfl([0]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e[1:*].toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[80]) * 100) ]);
			
			
	    	}
			else if(intInfl([1]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[81]) * 100) ]);
			
			
	    	}
	    	else if(intInfl([2]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[82]) * 100) ]);
			
			
	    	}
	    	else if(intInfl([3]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[83]) * 100) ]);
			
	    	}
	    	
			else if(intInfl([4]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[84]) * 100) ]);
			
	    	}
	    	
			else if(intInfl([5]) == true){
			
			thisNMap().e([1:*]) => new array([::)] moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[85]) * 100) ]);
			
			
	    	}
			
	    	else if(intInfl([6]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[86]) * 100) ]);
			
			
	    	}
			
			else if(intInfl([7]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[87]) * 100) ]);
			
			
	    	}
	    	else if(intInfl([8]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[88]) * 100) ]);
			
	    	}
	    	
			else if(intInfl[9] == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[89]) * 100) ]);
			
			
	    	}
	    	else if(intInfl([10]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[90]) * 100) ]);
			
			
	    	}
			else if(intInfl([11]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[91]) * 100) ]);
			
	    	}
			
			
			else if(intInfl([12]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[92]) * 100) ]);
			
	    	}
			
			else if(dependentInfl([0]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[93]) * 100) ]);
			
			
	    	}
			
			else if(dependentInfl([1]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[94]) * 100) ]);
			
			
	    	}
	    	
			else if(dependentInfl([2]) == true){
			
			thisNMap().e([1:*]) => new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[95]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([3]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[96]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([4]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[97]) * 100) ]);
			
			
	    	}
			
			else if(dependentInfl([5]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[98]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([6]) == true){
			
			thisNMap().e([1:*]) => new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[99]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([7]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[100]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([8]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[101]) * 100) ]);
			
			
	    	}
	    	else if(dependentInfl([9]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[102]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([10]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[103]) * 100) ]);
			
			
	    	}
			else if(dependentInfl([11]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[104]) * 100) ]);
			
			
	    	}
			
			else if(dependentInfl([12]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[105]) * 100) ]);
			
			
	    	}
			else if(opInfl([0]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e[1:*].toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[106]) * 100) ]);
			
			
	    	}
			else if(opInfl([1]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[107]) * 100) ]);
			
			
	    	}
	    	else if(opInfl([2]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[108]) * 100) ]);
			
			
	    	}
			else if(opInfl([3]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[109]) * 100) ]);
			
			
	    	}
	    	else if(opInfl([4]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[110]) * 100) ]);
			
			
	    	}
			else if(opInfl([5]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[111]) * 100) ]);
			
			
	    	}
			
			else if(opInfl([6]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[112]) * 100) ]);
			
			
	    	}
			else if(opInfl([7]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[113]) * 100) ]);
			
			
	    	}
	    	else if(opInfl([8]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[114]) * 100) ];
			
			
	    	}
			else if(opInfl([9]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[115]) * 100) ]);
			
			
	    	}
	    	
	    	else if(opInfl([10]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[116]) * 100) ]);
			
			
	    	}
			else if(opInfl[11] == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[117]) * 100) ]);
			
			
	    	}
	    	
	    	else if(opInfl([12]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[118]) * 100) ]);
			
			
	    	}
			else if(mildOpInfl([0]() == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE[1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[119]) * 100) ];
			
			
	    	}
	    	else if(mildOpInfl([1]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[120]) * 100) ]);
			
			
	    	}
	    	else if(mildOpInfl([2]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]().toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[121]) * 100) ]);
			
			
	    	}
	    	else if(mildOpInfl([3]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[122]) * 100) ]);
			
			
			
	    	}
	    	
	    	else if(mildOpInfl([4]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[123]) * 100) ]);
			
			
	    	}
	    	else if(mildOpInfl([5]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e[1:*].toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[124]) * 100) ]);
			
			
	    	}
	    	else if(mildOpInfl([6]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[125]) * 100) ]);
			
			
	    	}
	    	
	    	else if(mildOpInfl([7]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[126]) * 100) ]);
			
			
	    	}
	    	else if(mildOpInfl([8]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[127]) * 100) ]);
			
			
	    	}
	    	else if(mildOpInfl([9]) == true){
			
			thisNMap().e([1:*]) =>  new array([::]) moduleNMapE([1 : thisNMap().e([1:*]).toString() : 100/(2((double pos4([x,y]) - double pos3([x,y])) * repaReffCodes[128]) * 100) ]);
			
			
	    	}
	    	
	    	

			}
			else if(input2 == "f2"){

		//	2 : "Monetary Holdings" 
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "f3"){

		//	3
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "f4"){

		//	4
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
else if(input2 == "f5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
else if(input2 == "f6"){

		//	6  
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
  
  else if(input2 == "f7"){

		//	7 
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "f8"){

		//	8
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			
else if(input2 == "e9"){

		//	9
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e9"){

		//	 9
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
      else if(input2 == "e8"){

		//	8
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e6"){

		   //	6  
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e4"){

		//	4 
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e3"){

		//	3
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
      else if(input2 == "e2"){

		//	2
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "e1"){

		//	1
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "g1"){

		//	1
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "g2"){

		//	2 
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "g3"){

		//	3 
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
  else if(input2 == "h1"){

		//	1
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
  else if(input2 == "h2"){

		//	2 
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "h3"){

		//	3
		
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "h4"){

		//	4
		
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "h5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "h6"){

		//	6
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
      else if(input2 == "h7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "h8"){

		//	8
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "h9"){

		//	9
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "i9"){

		//	9
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
       else if(input2 == "i8"){

		//	8
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "i7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "i6"){

		//	6
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "i5"){
			  
			  
			  // 5
			  
			  new double pos5('[x,y]');
			  
			  this.thisDriftAlign('* arguments').get(*);
			  this.thisDriftAlign().Initialize(*);
			  this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
			  
			  
			  
			  
			}
			else if(input2 == "i4"){

		//	4
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "i3"){

		//	3
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
     else if(input2 == "i2"){

		//	2
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "i1"){

		//	1
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
     else if(input2 == "j1"){

		//	
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "j2"){

		//	
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "j3"){

		//	
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k1"){

		//	1
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k2"){

		//	2
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k3"){

		//	
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k4"){

		//	4
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k6"){

		//	6
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k8"){

		//	8
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "k9"){

		//	9
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l9"){

		//	9
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l8"){

		//	8
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l6"){

		//	6
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l4"){

		//	4
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l3"){

		//	l3
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l2"){

		//	2
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "l1"){

		//	1
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m1"){

		//	
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m2"){

		//	2
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m3"){

		//	3
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m4"){

		//	4
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m6"){

		//	6
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "m7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "n7"){

		//	7
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "n6"){

		// 6
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			else if(input2 == "n5"){

		//	5
			
			   new double pos5('[x,y]');
			
					this.thisDriftAlign('* arguments').get(*);
					this.thisDriftAlign().Initialize(*);
					this.thisDriftAlign(new double pos5(['x','y'])).return(* arguments);
					
  
			}
			
			
			else if(input2 != "g1" || "g2" || "g3" || "e1" || "e2" || "e3" || "e4" || "e5" || "e6" || "e7" || "e8" || "e9" || "f1" || "f2" ||
			"f3"  || "f4" || "f5" || "f6" || "f7" || "f8" || "f9" || "h1" || "h2" || "h3" || "h4" || "h5" || "h6" || "h7" || "h8" || "h9" || "i1" || "i2" || "i3" || "i4" || "i5" || "i6" || "i7" || "i8" || "i9" || "j1" || "j2" || "j3" || "k4" || "k5" || "k1" || "k2"		|| "k3"	 || "l1" || "l2" || "l3" || "l4" || "l5" || "l6" || "l7" || "m1" || "m2" || "m3" || "m4" ||
			"m5" || "m6" || "m7" || "n7" || "n6" || "n5" && input2 != ""){

			console.log('Iterating:: ...');
			
			else{

				console.log('!ThrowException NEW Exception: Error Identification ' + ${exceptionHandlerexceptionHandler.errorMessageObj} + '' + CurrentTimeDate().toString() );

                             
				}
      	
      	return 	moduleNMapE(['*:*']) && mildOpInfl(['* arguments']) && opInfl(['* arguments']) && detractantInfl(['* arguments']) && indInfl(['* arguments']) && direInfl(['* arguments']) && orbitalInfl(['* arguments']) && dependentInfl(['* arguments']);
		
	};
  
  
this.close();
		
  
module.exports = new _dataCipherPlotChorreography();

_dataCipherPlotChorreography().Initialize(this);
return module.exports('_dataCipherPlotChorreography');
 
  
