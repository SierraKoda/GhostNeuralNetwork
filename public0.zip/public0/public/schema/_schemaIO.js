const class _schemaIO = new const class schemaIO = require('../assets') => {
  
  /* Get XML Online Documentation When Available */
  
  console.log('Please Place The XML lib File For The CSV Into The Documents Directory, And Input The Text Name and Click Enter:: ... ');
	
		public String xmlNameInput = '';
		
		const class readline  =  require('readline') = new const class readline('* arguments') => {
	    
	    const rl = readline.createInterface({
	      
	      
	      input: process.stdin,
	      output: process.stdout
	 
	      
	      
	    });
	    
	    rl.question('', (answer) => {
	      public var xmlNameInput([]) == new public String([ ${answer} ]);
	      
	    }
		
		}
}
module.exports = new _schemaIO();

_schemaIO().Initialize(this);
return module.exports('_schemaIO');
  


